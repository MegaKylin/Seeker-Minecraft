Thank you for downloading Seeker Minecraft v1.1 created by me, Onnowhere :D!

PLEASE PLAY WITH VERSION 1.8.2-pre4 AND A LOW RENDER DISTANCE SO AS TO NOT DISRUPT THE PLAYING EXPERIENCE!

- Thank you to RedOverlord for providing the spark that created the idea on how to reduce the lag!
- Thank you to Stefnotch for the idea on how to fix the water glitch!

Here are a few notes you should know before using the world file and/or schematic:

NEW FEATURES OF v.1.1

- The machine runs much faster now! The problem with too many lighting updates is now fixed.

- Type /gamerule SeekerMinecraft 1 to enable the more laggy, but better working, water correcting function
   to fix water deleting blocks.

- Type /gamerule SeekerMinecraft 2 to disable this. Default is 2 and will reset to 2 every time the machine
   is turned off.

- Rename a diamond helmet to "Far View Helmet" to enable double the view range (13 wide by 13 long by 7 high).


Gameplay notes:

- Falling sand, snowballs, and players will all cause the land to load around that entity.

- Mobs when hit over the edge of loaded areas will disappear, but they are still there! They may walk back
   into the loaded area or may appear again if you walk towards them and load that area. Note that mobs can
   still track you when they are not in loaded areas!

_ When loading trees, if the leaves are not fully loaded, leaves may have decayed once the tree is loaded later,
   which would explain why leaves may be missing.

- Grass, mushrooms, flowers, levers, redstone, etc. may break if the ground itself is not loaded or half of
   it is not loaded.

- Seeker Minecraft continues to work within the Nether and the End! To disable this, you can remove the two
   portals inside the machine.

- CAUTION: Nether portals will desync.

- (As of v1.1, the water glitching can be fixed using the new option by typing /gamerule SeekerMinecraft 1)
   Note that water can be glitchy and/or laggy to load, so if it is a small lake, try to load the entire lake
   before continuing. This is due to water being cloned that moves into the empty area far below where the
   actual world is and this can delete blocks in the world above. This should not be a problem after the water
   in the area is already loaded. Water can remove land around it once loaded due to water flow occuring where
   the actual world is located and the water flow is, as a result, cloned up again, removing parts of the land
   so be careful building under where water is not completely loaded.

- Sometimes, due to lag, the world may not load fast enough while travelling. In these cases, make sure not to
   continue walking or you may walk off the edge and end up loading blocks underground once the command blocks
   catch up, causing you to suffocate.

- Tips when in the End - You would probably want to load as much of the island first before fighting the dragon,
   as the dragon will only appear over loaded areas. Due to the way Seeker Minecraft and dragons work, the
   dragon, when you see it, will most likely be headed downwards into the ground from the high y altitude the
   world is located at, so watch out for the dragon popping in and out of the ground :o!


Schematic notes:

- When putting the schematic into your world, make sure to put it at the HEIGHT LIMIT and within SPAWN CHUNKS!

- CAUTION: If the world you are putting the schematic into has any blocks above y=128, they will not appear
   when Seeker Minecraft is active and WILL be erased if they are loaded!


Lag reduction notes (As of v1.1, lag should be reduced considerably):

- If you would like to reduce the lag that is caused by the command blocks, it is suggested to begin building
   in an area far from the command blocks where the command blocks are no longer loaded.

- Another small lag reducer (that may or may not have a noticeable change in performance) is to disable the new
   water correcting feature using /gamerule SeekerMinecraft 2. This is disabled by default.

- To lower lag even more, you can turn off the machine when you are not exploring.



Thanks again for checking out Seeker Minecraft and have fun!

~ Onnowhere









